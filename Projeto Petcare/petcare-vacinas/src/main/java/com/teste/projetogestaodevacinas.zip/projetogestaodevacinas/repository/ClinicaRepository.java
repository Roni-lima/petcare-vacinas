package com.teste.projetogestaodevacinas.repository;

import com.teste.projetogestaodevacinas.model.Clinica;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClinicaRepository extends JpaRepository<Clinica, Long> {
}

